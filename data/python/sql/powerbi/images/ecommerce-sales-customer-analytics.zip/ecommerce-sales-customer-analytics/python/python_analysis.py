import pandas as pd
import numpy as np

df = pd.read_csv("../data/ecommerce_sales.csv", parse_dates=["Order_Date"])

# Basic cleaning
df = df.drop_duplicates()
df["Revenue"] = df["Revenue"].fillna(df["Quantity"] * df["Unit_Price"] * (1 - df["Discount"]))

# Core KPIs
total_revenue = df["Revenue"].sum()
orders = df["Order_ID"].nunique()
customers = df["Customer_ID"].nunique()
aov = total_revenue / orders

print(f"Revenue: {total_revenue:,.2f}")
print(f"Orders: {orders:,}")
print(f"Customers: {customers:,}")
print(f"Average Order Value: {aov:,.2f}")

# Business summaries
category_summary = (
    df.groupby("Category", as_index=False)
      .agg(Revenue=("Revenue","sum"), Orders=("Order_ID","nunique"))
      .sort_values("Revenue", ascending=False)
)
print("\nCategory performance:")
print(category_summary)

monthly = (
    df.assign(Month=df["Order_Date"].dt.to_period("M").astype(str))
      .groupby("Month", as_index=False)["Revenue"].sum()
)
monthly.to_csv("../data/monthly_revenue.csv", index=False)
category_summary.to_csv("../data/category_summary.csv", index=False)
