CREATE DATABASE IF NOT EXISTS ecommerce_analytics;
USE ecommerce_analytics;

CREATE TABLE ecommerce_sales (
    Order_ID VARCHAR(20),
    Order_Date DATE,
    Customer_ID VARCHAR(20),
    Product_ID VARCHAR(20),
    Product_Name VARCHAR(100),
    Category VARCHAR(50),
    Region VARCHAR(30),
    Channel VARCHAR(30),
    Quantity INT,
    Unit_Price DECIMAL(12,2),
    Discount DECIMAL(5,2),
    Revenue DECIMAL(14,2)
);

-- Load the CSV using your MySQL client/local setup.

-- 1. Revenue by category
SELECT Category, ROUND(SUM(Revenue),2) AS Revenue
FROM ecommerce_sales
GROUP BY Category
ORDER BY Revenue DESC;

-- 2. Monthly revenue
SELECT DATE_FORMAT(Order_Date,'%Y-%m') AS Month,
       ROUND(SUM(Revenue),2) AS Revenue
FROM ecommerce_sales
GROUP BY Month
ORDER BY Month;

-- 3. Channel performance
SELECT Channel,
       COUNT(DISTINCT Order_ID) AS Orders,
       ROUND(SUM(Revenue),2) AS Revenue,
       ROUND(SUM(Revenue)/COUNT(DISTINCT Order_ID),2) AS AOV
FROM ecommerce_sales
GROUP BY Channel
ORDER BY Revenue DESC;

-- 4. Top customers
SELECT Customer_ID,
       COUNT(DISTINCT Order_ID) AS Orders,
       ROUND(SUM(Revenue),2) AS Revenue
FROM ecommerce_sales
GROUP BY Customer_ID
ORDER BY Revenue DESC
LIMIT 20;

-- 5. Window function: rank products by revenue within category
SELECT *,
       DENSE_RANK() OVER (PARTITION BY Category ORDER BY Product_Revenue DESC) AS Product_Rank
FROM (
    SELECT Category, Product_ID, Product_Name,
           SUM(Revenue) AS Product_Revenue
    FROM ecommerce_sales
    GROUP BY Category, Product_ID, Product_Name
) x;
