# E-Commerce Sales & Customer Analytics

An end-to-end analytics project using Python, SQL/MySQL, Excel and Power BI to analyse e-commerce sales, customer behaviour, product performance and business KPIs.

## Tech Stack
- Python: Pandas, NumPy
- SQL: MySQL
- Excel: Pivot Tables, VLOOKUP/XLOOKUP, conditional formatting
- Power BI: interactive KPI and trend dashboard

## Repository Structure
- `data/` — synthetic e-commerce transaction dataset
- `python/` — cleaning and exploratory analysis
- `sql/` — MySQL schema and business queries
- `powerbi/` — dashboard design and KPI specification

## Key Analysis
- Revenue and order trends
- Category and product performance
- Regional and channel performance
- Customer purchase behaviour
- Average order value and repeat-customer metrics

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run `python/python_analysis.py`
3. Load `data/ecommerce_sales.csv` into MySQL and execute `sql/analysis_queries.sql`
4. Import the CSV into Power BI and create the measures listed in `powerbi/dashboard_kpis.md`

## Note
The included dataset is synthetic and created for portfolio/learning purposes. Replace it with your own dataset if you want to publish a real-world project.
