# Power BI Dashboard Specification

## KPI Cards
- Total Revenue
- Total Orders
- Unique Customers
- Average Order Value

## Recommended Visuals
1. Monthly revenue line chart
2. Revenue by category bar chart
3. Revenue by region map/bar chart
4. Revenue by channel
5. Top 10 products
6. Customer revenue segmentation

## Suggested Slicers
- Date
- Region
- Category
- Channel
